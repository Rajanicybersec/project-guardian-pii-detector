import pandas as pd
import re
import json
import sys

# Regex patterns for PII
patterns = {
    "phone": re.compile(r"\b\d{10}\b"),
    "aadhar": re.compile(r"\b\d{12}\b"),
    "passport": re.compile(r"\b[A-Z][0-9]{7}\b", re.IGNORECASE),
    "upi_id": re.compile(r"\b[\w.\-]+@\w+\b")
}

def mask_value(key, value):
    if key == "phone" and patterns["phone"].match(value):
        return value[:2] + "XXXXXX" + value[-2:]
    if key == "aadhar" and patterns["aadhar"].match(value):
        return value[:4] + "XXXXXXXX" + value[-4:]
    if key == "passport" and patterns["passport"].match(value):
        return value[0] + "XXXXXXX"
    if key == "upi_id" and patterns["upi_id"].match(value):
        parts = value.split("@")
        return parts[0][:2] + "XXXX@" + parts[1]
    if key in ["name"]:
        return " ".join([w[0] + "XXX" for w in value.split()])
    if key in ["email"]:
        return value[:2] + "XXX@" + value.split("@")[1]
    if key in ["address"]:
        return "[REDACTED_ADDRESS]"
    return value

def detect_pii(record):
    pii_detected = False
    record_redacted = {}
    combinatorial_keys = set()

    for key, val in record.items():
        if val is None or val == "":
            record_redacted[key] = val
            continue

        str_val = str(val)
        redacted_val = str_val

        # Standalone PII
        for pii_key, pattern in patterns.items():
            if pattern.search(str_val):
                pii_detected = True
                redacted_val = mask_value(pii_key, str_val)

        # Combinatorial PII
        if key in ["name", "email", "address", "ip_address", "device_id"]:
            combinatorial_keys.add(key)
            redacted_val = mask_value(key, str_val)

        record_redacted[key] = redacted_val

    if len(combinatorial_keys) > 1:
        pii_detected = True

    return record_redacted, pii_detected

def fix_json_string(s):
    return re.sub(r':\s*([A-Za-z0-9\-_]+)([}\],])', r': "\1"\2', s)

def main(input_csv):
    df = pd.read_csv(input_csv)
    output_records = []

    for idx, row in df.iterrows():
        raw = row["data_json"]
        try:
            record = json.loads(raw)
        except:
            record = json.loads(fix_json_string(raw))
        redacted_record, is_pii = detect_pii(record)
        output_records.append({
            "record_id": row["record_id"],
            "redacted_data_json": json.dumps(redacted_record),
            "is_pii": is_pii
        })

    redacted_df = pd.DataFrame(output_records)
    output_file = "redacted_output_candidate_full_name.csv"
    redacted_df.to_csv(output_file, index=False)
    print(f"[+] Output written to {output_file}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 detector_full_candidate_full_name.py <input_csv>")
    else:
        main(sys.argv[1])
