# Project Guardian 2.0 – PII Detector & Redactor

## Overview
This project is part of **Project Guardian 2.0**, designed to detect and redact PII from data streams to prevent fraud and unauthorized data leakage.

### Features
- Detects standalone PII (Phone, Aadhar, Passport, UPI ID).
- Detects combinatorial PII (Name + Email, Address + IP, etc.).
- Redacts values (e.g., `9876543210` → `98XXXXXX10`).
- Outputs a CSV with `redacted_data_json` and `is_pii` columns.

---

## Usage
```bash
python3 detector_nagubadi_rajani.py iscp_pii_dataset.csv
